import os
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
from flask import (Flask,render_template,request,redirect,url_for,session,flash,jsonify,send_from_directory)
from flask_wtf.csrf import CSRFProtect
from werkzeug.utils import secure_filename
from html import escape
from config import Config
from models import db, User, Course, Comment, Report
import click
import datetime
import re
import secrets
import string
import requests

csrf = CSRFProtect()


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    csrf.init_app(app)
    db.init_app(app)
    with app.app_context():
        db.create_all()

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)


    def admin_required(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            user_id = session.get("user_id")
            if not user_id:
                flash("You need to be logged in as an admin to access this page.", "warning")
                return redirect(url_for("login"))
            
            user = User.query.get(user_id)
            if not user or not user.is_admin:
                flash("You do not have permission to access this page.", "danger")
                return redirect(url_for("index"))

            return f(*args, **kwargs)
        return decorated_function

    def allowed_file(filename):
        return (
            "." in filename
            and filename.rsplit(".", 1)[1].lower() in app.config["ALLOWED_EXTENSIONS"]
        )

    def is_video_file(filename):
        ext = filename.rsplit(".", 1)[1].lower()
        return ext in {"mp4", "mkv", "webm", "mov"}


    def telegram_notify(text):
        token = "8463944596:AAGaSLP1fesMLJXFeYTK6nWjTu_GHSNWRJM" #privacy
        chat_id = "7863737666"  # privacy

        if not token or not chat_id:
            app.logger.error("Telegram BOT_TOKEN or CHAT_ID is not set.")
            return False

        try:
            url = f"https://api.telegram.org/bot{token}/sendMessage"
            payload = {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}
            response = requests.post(url, data=payload)
            if response.status_code == 200 and response.json().get("ok"):
                return True
            else:
                app.logger.error(f"Failed to send Telegram message. Status: {response.status_code}, Response: {response.text}")
                return False
        except Exception as e:
            app.logger.error(f"Telegram notify failed: {e}")
            return False


    @app.context_processor
    def inject_now():
        """Injects the current UTC datetime into the template context."""
        return {'now': datetime.datetime.utcnow()}

    @app.context_processor
    def inject_user():
        user_id = session.get('user_id')
        if user_id:
            return {'is_admin': session.get('is_admin', False)}
        return {'is_admin': False}

    @app.context_processor
    def utility_processor():
        return dict(Course=Course)

    @app.route("/")
    def home():
        return render_template("home.html")

    @app.route("/courses")
    def index():
        courses = Course.query.order_by(Course.created_at.desc()).all()
        return render_template("index.html", courses=courses)

    @app.route("/uploads/<filename>")
    @csrf.exempt
    def uploaded_file(filename):
        return send_from_directory(app.config["UPLOAD_FOLDER"], filename)

    @app.route("/upload", methods=["GET", "POST"])
    @admin_required
    @csrf.exempt
    def upload():
        if request.method == "POST":
            title = request.form.get("title", "").strip()
            description = request.form.get("description", "").strip()
            file = request.files.get("file")

            if not title or not file:
                flash("Please provide a title and a file.", "danger")
                return redirect(request.url)

            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                save_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)

                base, ext = os.path.splitext(filename)
                counter = 1
                while os.path.exists(save_path):
                    filename = f"{base}_{counter}{ext}"
                    save_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
                    counter += 1

                file.save(save_path)

                course = Course(
                    title=title,
                    description=description,
                    filename=filename,
                    is_video=is_video_file(filename),
                )
                db.session.add(course)
                db.session.commit()

                post_url = url_for("view_post", course_id=course.id, _external=True)
                telegram_notify(
                    f"New course uploaded: <b>{course.title}</b>\n{post_url}"
                )

                flash("Uploaded successfully!", "success")
                return redirect(url_for("view_post", course_id=course.id))

            else:
                flash("File type not allowed.", "danger")
                return redirect(request.url)

        return render_template("upload.html")

    @app.route("/post/<int:course_id>")
    def view_post(course_id):
        course = Course.query.get_or_404(course_id)
        return render_template("post.html", course=course)

    @app.route("/comment", methods=["POST"])
    def comment():
        data = request.get_json()
        course_id = data.get("course_id")
        name = data.get("name", "Anonymous")[:120]
        content = data.get("content", "").strip()

        if not content:
            return jsonify({"status": "error", "message": "Empty comment"}), 400

        course = Course.query.get(course_id)
        if not course:
            return jsonify({"status": "error", "message": "Course not found"}), 404

        cm = Comment(course_id=course_id, name=name, content=content)
        db.session.add(cm)
        db.session.commit()

        return jsonify(
            {
                "status": "ok",
                "comment": {
                    "id": cm.id,
                    "name": cm.name,
                    "content": cm.content,
                    "created_at": cm.created_at.isoformat(),
                },
            }
        )

    @app.route("/react", methods=["POST"])
    def react():
        data = request.get_json()
        course_id = data.get("course_id")
        action = data.get("action")

        course = Course.query.get(course_id)
        if not course:
            return jsonify({"status": "error", "message": "Course not found"}), 404

        liked_posts = session.get("liked_posts", [])
        if course_id in liked_posts:
            return jsonify({"status": "error", "message": "Already liked"}), 400

        if action == "like":
            course.likes += 1
            liked_posts.append(course_id)
            session["liked_posts"] = liked_posts
        else:
            return jsonify({"status": "error", "message": "Invalid action"}), 400

        db.session.commit()

        return jsonify(
            {
                "status": "ok",
                "likes": course.likes
            }
        )



    TELEGRAM_BOT_TOKEN = "8463944596:AAGaSLP1fesMLJXFeYTK6nWjTu_GHSNWRJM"  # privacy
    TELEGRAM_CHAT_ID = "7863737666"  # privacy

    @app.route("/contact", methods=["GET", "POST"])
    @csrf.exempt
    def contact():
        if request.method == "POST":
            name = request.form.get("name", "").strip()
            if not name:
                name = "Anonymous"
            message = request.form.get("message", "").strip() 
            course_id_str = request.form.get("course_id")
            
            if not message:
                flash("Please write a message.", "danger")
                return redirect(request.url)
            
            course_id = int(course_id_str) if course_id_str and course_id_str.isdigit() else None
            
            repo = Report(
                name=name,
                message=message,
                course_id=course_id,
            )
            db.session.add(repo)
            db.session.commit()

            secure_name = escape(name)
            secure_message = escape(message)

            if course_id is not None:
                course = Course.query.get(course_id)
                post_url = url_for("view_post", course_id=course_id, _external=True)
                telegram_message = (
                    f"<b>🚨 New Report Received!</b>\n\n"
                    f"<b>Post:</b> <a href='{post_url}'>{escape(course.title)}</a>\n"
                    f"<b>From:</b> {secure_name}\n\n"
                    f"<b>Message:</b>\n{secure_message}"
                )
            else:
                telegram_message = f"<b>📩 New Contact Message!</b>\n\n<b>From:</b> {secure_name}\n\n<b>Message:</b>\n{secure_message}"

            if telegram_notify(telegram_message):
                flash("Thank you! Your message was sent.", "success")
            else:
                flash("Sorry, there was an error sending your message. Please try again later.", "danger")
            return redirect(url_for("contact"))

        return render_template("contact.html")

    @app.route("/admin")
    @admin_required
    def admin():
        courses = Course.query.order_by(Course.created_at.desc()).all()
        reports = Report.query.order_by(Report.created_at.desc()).all()
        return render_template("admin.html", courses=courses, reports=reports)

    @app.route("/login", methods=["GET", "POST"])
    @csrf.exempt
    def login():
        if session.get("user_id"):
            return redirect(url_for("home"))

        if request.method == "POST":
            username = request.form.get("username")
            password = request.form.get("password")
            user = User.query.filter(
                (User.username == username) | (User.email == username)
            ).first()

            if user and check_password_hash(user.password_hash, password):
                session["user_id"] = user.id
                session["username"] = user.username
                session["is_admin"] = user.is_admin
                next_url = request.args.get("next")
                flash("You were successfully logged in.", "success")
                if user.is_admin:
                    return redirect(next_url or url_for("admin"))
                return redirect(next_url or url_for("home"))
            else:
                flash("Invalid username or password.", "danger")

        return render_template("login.html")

    
    @app.route("/register", methods=["GET", "POST"])
    @csrf.exempt
    def register():
        if session.get("user_id"):
            return redirect(url_for("home"))

        if request.method == "POST":
            username = request.form.get("username")
            password = request.form.get("password")
            confirm_password = request.form.get("confirm_password")
            email = request.form.get("email")
            user_captcha = request.form.get("captcha")


            captcha_text = ''.join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(6))
            
            if not user_captcha or user_captcha.upper() != session.get('captcha', '').upper():
                session['captcha'] = captcha_text
                flash("Invalid CAPTCHA. Please try again.", "danger")
                return render_template("register.html", captcha=captcha_text, username=username, email=email)

            if not username or not password or not email:
                flash("Username, email, and password are required.", "danger")
                return render_template("register.html", captcha=captcha_text, username=username, email=email)

            if len(username) < 3 or len(username) > 20:
                flash("Username must be between 3 and 20 characters.", "danger")
                return render_template("register.html", captcha=captcha_text, username=username, email=email)

            if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
                flash("Invalid email address.", "danger")
                return render_template("register.html", captcha=captcha_text, username=username, email=email)

            if password != confirm_password:
                flash("Passwords do not match.", "danger")
                return render_template("register.html", captcha=captcha_text, username=username, email=email)

            if len(password) < 8:
                flash("Password must be at least 8 characters long.", "danger")
                return render_template("register.html", captcha=captcha_text, username=username, email=email)

            if User.query.filter_by(username=username).first():
                flash("Username already exists.", "danger")
                return render_template("register.html", captcha=captcha_text, username=username, email=email)

            if User.query.filter_by(email=email).first():
                flash("Email address already registered.", "danger")
                return render_template("register.html", captcha=captcha_text, username=username, email=email)

            is_admin = False
            admin_email = "sergioxbins@xbins.com"
            if User.query.count() == 0 and email == admin_email:
                is_admin = True

            new_user = User(
                username=username,
                password_hash=generate_password_hash(password),
                email=email,
                is_admin=is_admin
            )
            db.session.add(new_user)
            db.session.commit()

            session.pop('captcha', None) 
            flash("Registration successful! Please log in.", "success")
            return redirect(url_for("login"))


        captcha_text = ''.join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(6))
        session['captcha'] = captcha_text
        return render_template("register.html", captcha=captcha_text)

    @app.route("/logout")
    def logout():
        session.clear()
        flash("You have been logged out.", "success")
        return redirect(url_for("home"))

    @app.route("/delete_course/<int:course_id>", methods=["POST"])
    @admin_required
    def delete_course(course_id):
        course = Course.query.get_or_404(course_id)

        if course.filename:
            file_path = os.path.join(app.config["UPLOAD_FOLDER"], course.filename)
            if os.path.exists(file_path):
                os.remove(file_path)

        db.session.delete(course)
        db.session.commit()
        flash(f"Course '{course.title}' has been deleted.", "success")
        return redirect(url_for("admin"))

    @app.cli.command("create-admin")
    @click.argument("username")
    @click.argument("email")
    @click.argument("password")
    def create_admin(username, email, password):
        """Creates a new admin user."""
        if User.query.filter_by(username=username).first() or User.query.filter_by(email=email).first():
            print("Error: A user with that username or email already exists.")
            return

        admin_user = User(username=username, email=email, password_hash=generate_password_hash(password), is_admin=True)
        db.session.add(admin_user)
        db.session.commit()
        print(f"Admin user '{username}' created successfully.")

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)
