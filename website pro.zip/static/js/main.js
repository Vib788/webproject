async function postComment(courseId) {
    const contentEl = document.getElementById('comment-text');
    const content = contentEl.value;
    if (!content.trim()) {
        alert('Please write a comment.');
        return;
    }

    try {
        const res = await fetch('/comment', {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({course_id: courseId, content})
        });
        const data = await res.json();
        if (data.status === 'ok') {
            const list = document.getElementById('comments-list');
            const newComment = document.createElement('div');
            newComment.className = 'flex space-x-3';
            const commentDate = new Date(data.comment.created_at);
            const formattedDate = commentDate.toLocaleString('default', { month: 'short', day: 'numeric', year: 'numeric' });

            newComment.innerHTML = `
                <div class="flex-shrink-0">
                    <div class="h-10 w-10 rounded-full bg-gray-700 flex items-center justify-center font-bold text-cyan-400">
                        ${data.comment.name[0].toUpperCase()}
                    </div>
                </div>
                <div class="flex-1">
                    <div class="card p-3 rounded-lg">
                        <p class="text-gray-300">${data.comment.content}</p>
                    </div>
                    <div class="text-xs text-gray-500 mt-1 pl-1">
                        <strong>${data.comment.name}</strong> &middot; <span title="${commentDate.toISOString()}">${formattedDate}</span>
                    </div>
                </div>
            `;
            list.prepend(newComment);
            contentEl.value = '';
        } else {
            alert(data.message || 'Failed to post comment.');
        }
    } catch (error) {
        console.error("Error posting comment:", error);
        alert("An error occurred. Please try again.");
    }
}

async function react(courseId, action) {
    const res = await fetch('/react', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({course_id: courseId, action})
    });
    const data = await res.json();
    if (data.status === 'ok') {
        document.getElementById('likes-count').textContent = data.likes;
    } else {
        console.warn(data.message);
    }
}

function openReportModal(courseId) {
    document.getElementById('report-course-id').value = courseId;
    document.getElementById('report-modal').classList.remove('hidden');
}

function closeReportModal() {
    document.getElementById('report-modal').classList.add('hidden');
}
