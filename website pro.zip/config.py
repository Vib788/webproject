import os
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = os.path.abspath(os.path.dirname(__file__))



class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "change-me")
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        "DATABASE_URL", f"sqlite:///{os.path.join(BASE_DIR, 'xb1ns.db')}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = os.environ.get("UPLOAD_FOLDER", os.path.join(BASE_DIR, "uploads"))
    ALLOWED_EXTENSIONS = set(
        os.environ.get("ALLOWED_EXTENSIONS", "mp4,mkv,webm,mov,jpg,jpeg,png,gif,avi,wmv,flv,m4v,mpg,mpeg,3gp,ogv,ts,m2ts,divx,asf,bmp,tiff,tif,webp,heic,heif,svg,ico,eps,raw,cr2,nef,arw,apng,gifv,mng").split(
            ","
        )
    )
    # It's better to not have default secrets in code.
    # The app will log an error if these are not set in the environment.
    TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
    TELEGRAM_ADMIN_CHAT_ID = os.environ.get("TELEGRAM_ADMIN_CHAT_ID")
