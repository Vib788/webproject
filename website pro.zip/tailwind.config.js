/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./templates/**/*.html"],
  theme: {
    extend: {
      colors: {
        'dark-primary': '#0d0d0d',
        'dark-secondary': '#1a1a1a',
        'dark-accent': '#333333',
        'neon-green': '#00ff00',
        'dark-green': '#003300',
        'light-gray': '#cccccc',
        'medium-gray': '#999999',
        'dark-gray': '#555555',
        'glitch-red': '#ff0000',
        'glitch-blue': '#0000ff',
      },
      fontFamily: {
        'mono': ['VT323', 'monospace'],
      },
      textShadow: {
        'neon': '0 0 5px #00ff00, 0 0 10px #00ff00',
      },
    },
  },
  plugins: [require('tailwindcss-textshadow')],
}